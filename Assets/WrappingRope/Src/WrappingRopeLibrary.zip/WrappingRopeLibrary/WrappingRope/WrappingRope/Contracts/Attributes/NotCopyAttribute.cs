﻿using System;

namespace WrappingRopeLibrary.Attributes
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    class NotCopyAttribute : Attribute
    {

    }
}
